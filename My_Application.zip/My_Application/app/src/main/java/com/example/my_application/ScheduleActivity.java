package com.example.my_application;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import static com.example.my_application.MainActivity.data;

public class ScheduleActivity extends AppCompatActivity {
    ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, data);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner spinner = findViewById(R.id.spinner);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                if(position==0){
//                    Intent intent = new Intent(ScheduleActivity.this,MainActivity.class);
//                    startActivity(intent);
//                }
                if(position==1){
                    Intent intent = new Intent(ScheduleActivity.this,BaseActivity.class);
                    startActivity(intent);
                }
                if(position==2){
                    Intent intent = new Intent(ScheduleActivity.this,TableOfResults.class);
                    startActivity(intent);
                }
//                if(position==3){
//                    Intent intent = new Intent(ScheduleActivity.this,ScheduleActivity.class);
//                    startActivity(intent);
//                }
                if(position==4){
                    Intent intent = new Intent(ScheduleActivity.this,EmissionFactorActivity.class);
                    startActivity(intent);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}
