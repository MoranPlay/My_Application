package com.example.my_application;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import static com.example.my_application.MainActivity.data;

public class BaseActivity extends AppCompatActivity {
//    Button add_base_button, ref_base_button, del_base_button;
//    EditText enter_city, year_edit, petrol_edit, diesel_edit, treated_wastewater_edit, untreated_waste_water_edit, activated_sludge_edit;
private EditText mEnterCity;

    private EditText mYear;
    private EditText mPetrol;
    private EditText mDiesel;
    private EditText mTreated;
    private EditText mUntreated;
    private EditText mActivated;
//    private Button mAdCityButton;
//    private Button mDelCityButton;
DBHelper dbHelper;
    ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base);

        mEnterCity = (EditText) findViewById(R.id.enter_city);

        mYear = (EditText) findViewById(R.id.year_edit);
        mPetrol = (EditText) findViewById(R.id.petrol_edit);
        mDiesel = (EditText) findViewById(R.id.diesel_edit);
        mTreated = (EditText) findViewById(R.id.treated_wastewater_edit);
        mUntreated = (EditText) findViewById(R.id.untreated_waste_water_edit);
        mActivated = (EditText) findViewById(R.id.activated_sludge_edit);
//        mAdCityButton = (Button) findViewById(R.id.ad_city_button);
//        mDelCityButton = (Button) findViewById(R.id.del_city_button);

        dbHelper= new DBHelper(this);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, data);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner spinner = findViewById(R.id.spinner);
        spinner.setAdapter(adapter);
        //spinner.setSelection(1);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                if(position==0){
//                    Intent intent = new Intent(BaseActivity.this,MainActivity.class);
//                    startActivity(intent);
////                    BaseActivity.super.onPause();
//                }
                if(position==1){
                    Intent intent = new Intent(BaseActivity.this,BaseActivity.class);
                    startActivity(intent);
                }
                if(position==2){
                    Intent intent = new Intent(BaseActivity.this,TableOfResults.class);
                    startActivity(intent);
                }
                if(position==3){
                    Intent intent = new Intent(BaseActivity.this,ScheduleActivity.class);
                    startActivity(intent);
                }
                if(position==4){
                    Intent intent = new Intent(BaseActivity.this,EmissionFactorActivity.class);
                    startActivity(intent);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }


    public void onClick(View view){


        SQLiteDatabase database = dbHelper.getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        switch (view.getId()){
            case R.id.ad_city_button:
                contentValues.put(DBHelper.NAME, mEnterCity.getText().toString());
                database.insert(DBHelper.TABLE_CITY,null,contentValues);
//
                break;

            case R.id.del_city_button:
                Cursor query = database.rawQuery("SELECT * FROM cities;", null);
                //Cursor cursor = database.query(DBHelper.TABLE_CITY, null,null,null,null,null,null);
                if(query.moveToFirst()){

                   // int cityColumnIndex = query.getColumnIndex(DBHelper.NAME);
//
                    do{
                        Log.d("mLog", "city = " + query.getString(1) + "city_id = " + query.getString(0));
                    } while (query.moveToNext());

                }
                else Log.d("mLog", "0 rows");

                query.close();
//             database.delete(DBHelper.TABLE_CITY,null,null);
              break;

            case R.id.add_base_button:
                contentValues.put(DBHelper.CITY_ID, 1);
                contentValues.put(DBHelper.YEAR, Integer.parseInt(mYear.getText().toString()));
                contentValues.put(DBHelper.PETROL, Double.valueOf(mPetrol.getText().toString()));
                contentValues.put(DBHelper.DIESEL, Double.valueOf(mDiesel.getText().toString()));
                contentValues.put(DBHelper.TREATED_WASTEWATER, Double.valueOf(mTreated.getText().toString()));
                contentValues.put(DBHelper.UNTREATED_WASTEWATER, Double.valueOf(mUntreated.getText().toString()));
                contentValues.put(DBHelper.ACTIVATED_SLUDGE, Double.valueOf(mActivated.getText().toString()));
                database.insert(DBHelper.TABLE_DATA,null,contentValues);
//
                break;

                case R.id.ref_base_button:
                     query = database.rawQuery("SELECT * FROM data_city;", null);
                    //Cursor cursor = database.query(DBHelper.TABLE_CITY, null,null,null,null,null,null);
                    if(query.moveToFirst()){

                        // int cityColumnIndex = query.getColumnIndex(DBHelper.NAME);
//
                        do{
                            Log.d("mLog", "айди данных =  " + query.getString(0)
                                    + "айди города = " + query.getString(1)
                                    + "год = " + query.getString(2)
                                    + " бензин = " + query.getString(3)
                                    + " дизель  = " + query.getString(4)
                                    + "очищенный = " + query.getString(5)
                                    + "неочищенный  = " + query.getString(6)
                                    + "активированный  = " + query.getString(7));
                        } while (query.moveToNext());

                    }
                    else Log.d("mLog", "0 rows");

                    query.close();
                    break;
        }
        dbHelper.close();

    }


}
