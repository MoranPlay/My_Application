package com.example.my_application;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper{

private  static final int DATABASE_VERSION=1;
    public static final String DATABASE_NAME="cityDB";

    public static final String TABLE_CITY="cities";
    public static final String TABLE_DATA="data_city";

    public static final String NAME = "city";
    public static final String NAME_ID = "city_id";

    public static final String DATA_ID="data_id";
    public static final String CITY_ID="data_city_id";
    public static final String YEAR="year";
    public static final String PETROL="petrol";
    public static final String DIESEL="diesel";
    public static final String TREATED_WASTEWATER="treated_waste_water";
    public static final String UNTREATED_WASTEWATER="untreated_waste_water";
    public static final String ACTIVATED_SLUDGE="activated_sludge";

    public static final String CREATE_TABLE_CITY = "CREATE TABLE IF NOT EXISTS " + TABLE_CITY
            + " ( " +NAME_ID + " INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE, " + NAME
            + " TEXT NOT NULL )";

    public static final String CREATE_TABLE_DATA = "CREATE TABLE IF NOT EXISTS " +
            TABLE_DATA + " (" +
            DATA_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            CITY_ID + " INTEGER, " +
            YEAR + " INTEGER, " +
            PETROL + " REAL, " +
            DIESEL + " REAL, " +
            TREATED_WASTEWATER + " REAL, " +
            UNTREATED_WASTEWATER + " REAL, " +
            ACTIVATED_SLUDGE + " REAL, " +
            "FOREIGN KEY(" + CITY_ID + ") REFERENCES " +
            TABLE_CITY + " (" + NAME_ID + ") " + ")";


    public DBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
    db.execSQL(CREATE_TABLE_CITY);
    db.execSQL(CREATE_TABLE_DATA);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
